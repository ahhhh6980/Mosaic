flags:
-p:	palette name
-f:	file name
-v:	variance (0 for none)
-fs:	max size of width or height of image
-ps:	max size of width or height of palette
